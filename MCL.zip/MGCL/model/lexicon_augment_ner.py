import numpy as np
import torch
import torch.nn as nn
from transformers import BertConfig
from .crf import CRF
from .ner_layers import NERmodel
from transformers import BertModel

class GazLSTM(nn.Module):
    def __init__(self, data, tau, lamb1, lamb2, lamb3, lamb4):
        super(GazLSTM, self).__init__()
        self.tau = tau
        self.lamb1 = lamb1
        self.lamb2 = lamb2
        self.lamb3 = lamb3
        self.lamb4 = lamb4
        self.gpu = data.HP_gpu
        self.use_biword = data.use_bigram
        self.hidden_dim = data.HP_hidden_dim
        self.gaz_alphabet = data.gaz_alphabet
        self.gaz_emb_dim = data.gaz_emb_dim
        self.word_emb_dim = data.word_emb_dim
        self.biword_emb_dim = data.biword_emb_dim
        self.use_char = data.HP_use_char
        self.bilstm_flag = data.HP_bilstm
        self.lstm_layer = data.HP_lstm_layer
        self.use_count = data.HP_use_count
        self.num_layer = data.HP_num_layer
        self.model_type = data.model_type
        self.use_bert = data.use_bert

        scale = np.sqrt(3.0 / self.gaz_emb_dim)
        data.pretrain_gaz_embedding[0, :] = np.random.uniform(-scale, scale, [1, self.gaz_emb_dim])

        if self.use_char:
            scale = np.sqrt(3.0 / self.word_emb_dim)
            data.pretrain_word_embedding[0, :] = np.random.uniform(-scale, scale, [1, self.word_emb_dim])

        self.gaz_embedding = nn.Embedding(data.gaz_alphabet.size(), self.gaz_emb_dim)
        self.word_embedding = nn.Embedding(data.word_alphabet.size(), self.word_emb_dim)
        if self.use_biword:
            self.biword_embedding = nn.Embedding(data.biword_alphabet.size(), self.biword_emb_dim)

        if data.pretrain_gaz_embedding is not None:
            self.gaz_embedding.weight.data.copy_(torch.from_numpy(data.pretrain_gaz_embedding))
        else:
            self.gaz_embedding.weight.data.copy_(
                torch.from_numpy(self.random_embedding(data.gaz_alphabet.size(), self.gaz_emb_dim)))

        if data.pretrain_word_embedding is not None:
            self.word_embedding.weight.data.copy_(torch.from_numpy(data.pretrain_word_embedding))
        else:
            self.word_embedding.weight.data.copy_(
                torch.from_numpy(self.random_embedding(data.word_alphabet.size(), self.word_emb_dim)))
        if self.use_biword:
            if data.pretrain_biword_embedding is not None:
                self.biword_embedding.weight.data.copy_(torch.from_numpy(data.pretrain_biword_embedding))
            else:
                self.biword_embedding.weight.data.copy_(
                    torch.from_numpy(self.random_embedding(data.biword_alphabet.size(), self.word_emb_dim)))

        # self.p_lambda = nn.Parameter(torch.FloatTensor([0.5]).cuda(), requires_grad=True)  # .cuda()
        char_feature_dim = self.word_emb_dim + 4 * self.gaz_emb_dim

        char_feature_dim2 = self.word_emb_dim + self.gaz_emb_dim

        # char_feature_dim = self.word_emb_dim

        if self.use_biword:
            char_feature_dim += self.biword_emb_dim

        if self.use_bert:
            char_feature_dim = char_feature_dim + 768
            char_feature_dim2 = char_feature_dim2 + 768
        ## lstm model
        if self.model_type == 'lstm':
            lstm_hidden = self.hidden_dim
            if self.bilstm_flag:
                self.hidden_dim *= 2
            self.NERmodel = NERmodel(model_type='lstm', input_dim=char_feature_dim, hidden_dim=lstm_hidden,
                                     num_layer=self.lstm_layer, biflag=self.bilstm_flag)

        self.hidden2tag_v2 = nn.Linear(char_feature_dim2, char_feature_dim)

        self.hidden2tag_v3 = nn.Linear(self.word_emb_dim,  self.word_emb_dim+ 4 * self.gaz_emb_dim)
        self.hidden2tag_v4 = nn.Linear(50,40)
        ## cnn model
        if self.model_type == 'cnn':
            self.NERmodel = NERmodel(model_type='cnn', input_dim=char_feature_dim, hidden_dim=self.hidden_dim,
                                     num_layer=self.num_layer, dropout=data.HP_dropout, gpu=self.gpu)

        ## attention model
        if self.model_type == 'transformer':
            self.NERmodel = NERmodel(model_type='transformer', input_dim=char_feature_dim, hidden_dim=self.hidden_dim,
                                     num_layer=self.num_layer, dropout=data.HP_dropout)

        self.drop = nn.Dropout(p=data.HP_dropout)
        self.hidden2tag = nn.Linear(self.hidden_dim, data.label_alphabet_size + 2)
        self.crf = CRF(data.label_alphabet_size, self.gpu)

        self.head = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Linear(50, 50),
        )
        self.head2 = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Linear(self.gaz_emb_dim * 4, 50),
        )
        if self.use_bert:
            config = BertConfig.from_json_file('cpt/config.json')
            self.bert_encoder = BertModel.from_pretrained('cpt', config=config)
            for p in self.bert_encoder.parameters():
                p.requires_grad = False

        if self.gpu:
            self.gaz_embedding = self.gaz_embedding.cuda()
            self.word_embedding = self.word_embedding.cuda()
            if self.use_biword:
                self.biword_embedding = self.biword_embedding.cuda()
            self.NERmodel = self.NERmodel.cuda()
            self.head = self.head.cuda()
            self.hidden2tag = self.hidden2tag.cuda()
            self.crf = self.crf.cuda()
            self.head2 = self.head2.cuda()
            self.hidden2tag_v2 = self.hidden2tag_v2.cuda()
            self.hidden2tag_v3 = self.hidden2tag_v3.cuda()
            self.hidden2tag_v4 = self.hidden2tag_v4.cuda()
            if self.use_bert:
                self.bert_encoder = self.bert_encoder.cuda()

    def get_tags(self, gaz_list, word_inputs, biword_inputs, layer_gaz, gaz_count, gaz_chars, gaz_mask_input,
                 gazchar_mask_input, mask, word_seq_lengths, batch_bert, bert_mask):

        batch_size = word_inputs.size()[0]
        seq_len = word_inputs.size()[1]
        max_gaz_num = layer_gaz.size(-1)
        gaz_match = []

        word_embs = self.word_embedding(word_inputs)

        if self.use_biword:
            biword_embs = self.biword_embedding(biword_inputs)
            word_embs = torch.cat([word_embs, biword_embs], dim=-1)

        if self.model_type != 'transformer':
            word_inputs_d = self.drop(word_embs)  # (b,l,we)
        else:
            word_inputs_d = word_embs

        if self.use_char:
            gazchar_embeds = self.word_embedding(gaz_chars)

            gazchar_mask = gazchar_mask_input.unsqueeze(-1).repeat(1, 1, 1, 1, 1, self.word_emb_dim)
            gazchar_embeds = gazchar_embeds.data.masked_fill_(gazchar_mask.data, 0)  # (b,l,4,gl,cl,ce)

            # gazchar_mask_input:(b,l,4,gl,cl)
            gaz_charnum = (gazchar_mask_input == 0).sum(dim=-1, keepdim=True).float()  # (b,l,4,gl,1)
            gaz_charnum = gaz_charnum + (gaz_charnum == 0).float()
            gaz_embeds = gazchar_embeds.sum(-2) / gaz_charnum  # (b,l,4,gl,ce)

            if self.model_type != 'transformer':
                gaz_embeds = self.drop(gaz_embeds)
            else:
                gaz_embeds = gaz_embeds

        else:  # use gaz embedding
            gaz_embeds = self.gaz_embedding(layer_gaz)

            if self.model_type != 'transformer':
                gaz_embeds_d = self.drop(gaz_embeds)
            else:
                gaz_embeds_d = gaz_embeds

            gaz_mask = gaz_mask_input.unsqueeze(-1).repeat(1, 1, 1, 1, self.gaz_emb_dim)

            gaz_embeds = gaz_embeds_d.data.masked_fill_(gaz_mask.data, 0)  # (b,l,4,g,ge)  ge:gaz_embed_dim

        if self.use_count:
            count_sum = torch.sum(gaz_count, dim=3, keepdim=True)  # (b,l,4,gn)
            count_sum = torch.sum(count_sum, dim=2, keepdim=True)  # (b,l,1,1)

            weights = gaz_count.div(count_sum)  # (b,l,4,g)
            weights = weights * 4
            weights = weights.unsqueeze(-1)
            gaz_embeds = weights * gaz_embeds  # (b,l,4,g,e)
            gaz_embeds = torch.sum(gaz_embeds, dim=3)  # (b,l,4,e)

        else:
            gaz_num = (gaz_mask_input == 0).sum(dim=-1, keepdim=True).float()  # (b,l,4,1)
            gaz_embeds = gaz_embeds.sum(-2) / gaz_num  # (b,l,4,ge)/(b,l,4,1)

        gaz_embeds_cat = gaz_embeds.view(batch_size, seq_len, -1)  # (b,l,4*ge)
        word_inputs_d = self.head(word_inputs_d)
        word_input_cat = torch.cat([word_inputs_d, gaz_embeds_cat], dim=-1)  # (b,l,we+4*ge)

        ### cat bert feature
        if self.use_bert:
            seg_id = torch.zeros(bert_mask.size()).long().cuda()
            outputs = self.bert_encoder(batch_bert, bert_mask, seg_id)
            outputs = outputs[0][:, 1:-1, :]

        representations = self.NERmodel(word_input_cat)

        tags = self.hidden2tag(representations)

        return tags, gaz_match

    def Contrastive_Loss(self, gaz_list, word_inputs, biword_inputs, layer_gaz, gaz_count, gaz_chars, gaz_mask_input,
                gazchar_mask_input, mask, word_seq_lengths, batch_bert, bert_mask):
        batch_size = word_inputs.size()[0]
        seq_len = word_inputs.size()[1]
        max_gaz_num = layer_gaz.size(-1)
        gaz_match = []

        word_embs = self.word_embedding(word_inputs)

        if self.use_biword:
            biword_embs = self.biword_embedding(biword_inputs)
            word_embs = torch.cat([word_embs, biword_embs], dim=-1)

        if self.model_type != 'transformer':
            word_inputs_d = self.drop(word_embs)  # (b,l,we)
        else:
            word_inputs_d = word_embs

        if self.use_char:
            gazchar_embeds = self.word_embedding(gaz_chars)

            gazchar_mask = gazchar_mask_input.unsqueeze(-1).repeat(1, 1, 1, 1, 1, self.word_emb_dim)
            gazchar_embeds = gazchar_embeds.data.masked_fill_(gazchar_mask.data, 0)  # (b,l,4,gl,cl,ce)

            # gazchar_mask_input:(b,l,4,gl,cl)
            gaz_charnum = (gazchar_mask_input == 0).sum(dim=-1, keepdim=True).float()  # (b,l,4,gl,1)
            gaz_charnum = gaz_charnum + (gaz_charnum == 0).float()
            gaz_embeds = gazchar_embeds.sum(-2) / gaz_charnum  # (b,l,4,gl,ce)

            if self.model_type != 'transformer':
                gaz_embeds = self.drop(gaz_embeds)
            else:
                gaz_embeds = gaz_embeds

        else:  # use gaz embedding
            gaz_embeds = self.gaz_embedding(layer_gaz)

            if self.model_type != 'transformer':
                gaz_embeds_d = self.drop(gaz_embeds)
            else:
                gaz_embeds_d = gaz_embeds

            gaz_mask = gaz_mask_input.unsqueeze(-1).repeat(1, 1, 1, 1, self.gaz_emb_dim)

            gaz_embeds = gaz_embeds_d.data.masked_fill_(gaz_mask.data, 0)  # (b,l,4,g,ge)  ge:gaz_embed_dim

        if self.use_count:
            count_sum = torch.sum(gaz_count, dim=3, keepdim=True)  # (b,l,4,gn)
            count_sum = torch.sum(count_sum, dim=2, keepdim=True)  # (b,l,1,1)

            weights = gaz_count.div(count_sum)  # (b,l,4,g)
            weights = weights * 4
            weights = weights.unsqueeze(-1)
            gaz_embeds = weights * gaz_embeds  # (b,l,4,g,e)
            gaz_embeds = torch.sum(gaz_embeds, dim=3)  # (b,l,4,e)

        else:
            gaz_num = (gaz_mask_input == 0).sum(dim=-1, keepdim=True).float()  # (b,l,4,1)
            gaz_embeds = gaz_embeds.sum(-2) / gaz_num  # (b,l,4,ge)/(b,l,4,1)
        gaz_embeds_cat2 = gaz_embeds[:, :, 0, :]
        gaz_embeds_cat = gaz_embeds.view(batch_size, seq_len, -1)  # (b,l,4*ge)
        word_inputs_d = self.head(word_inputs_d)
        # word_inputs_d = self.NERmodel2(word_inputs_d)
        word_input_cat = torch.cat([word_inputs_d, gaz_embeds_cat], dim=-1)  # (b,l,we+4*ge)
        word_input_cat2 = torch.cat([word_inputs_d, gaz_embeds_cat2], dim=-1)  # (b,l,we+4*ge)
        word_input_cat3 = self.hidden2tag_v3(word_inputs_d)
        ### cat bert feature
        if self.use_bert:
            seg_id = torch.zeros(bert_mask.size()).long().cuda()
            outputs = self.bert_encoder(batch_bert, bert_mask, seg_id)
            outputs = outputs[0][:, 1:-1, :]

        representations_ori = self.NERmodel(word_input_cat)

        word_input_cat2 = self.hidden2tag_v2(word_input_cat2)

        representations_pos = self.NERmodel(word_input_cat2)
        representations_neg = self.NERmodel(word_input_cat3 )

        loss_bcl = self.BCL(representations_ori,  representations_pos ,  representations_neg)

        representations_word = self.head2(gaz_embeds_cat)
        representations_character = word_inputs_d

        tags = self.hidden2tag( representations_ori )
        loss_ccl = self.CCL(  representations_character, representations_word , word_inputs)
        return loss_bcl, loss_ccl, tags

    # cross-granularity contrastive learning
    def CCL(self, representations, representations_bmes, word_inputs):

        batch_size = representations.size(0)
        feature_dim = representations.size(2)
        similarity_function = nn.CosineSimilarity(dim=-1)

        loss = 0
        # sentence_length = representations.size(1)
        feature_dim = representations.size(2)

        for s in range(batch_size):
            temp_word_inputs = word_inputs[s].detach().cpu().numpy().flatten()
            set1 = set()
            idx_list = []

            for idx, id in enumerate(temp_word_inputs):
                if id not in set1:
                    set1.add(id)
                    idx_list.append(idx)
                else:
                    continue
            anchor_feature = representations[s, idx_list, :]
            contrast_feature = representations_bmes[s, idx_list, :]
            sentence_length = len(idx_list)
            anchor_dot_contrast = similarity_function(
                anchor_feature.expand((sentence_length, sentence_length, feature_dim)),
                torch.transpose(contrast_feature.expand((sentence_length, sentence_length, feature_dim)), 0, 1))
            loss += -nn.LogSoftmax(0)(torch.div(anchor_dot_contrast, self.tau)).diag().sum()
        return loss/10

    # bi-granularity contrastive learning
    def BCL(self, representations, representations_pos, representations_neg):
        batch_size = representations.size(0)
        sentence_length = representations.size(1)
        similarity_function = nn.CosineSimilarity(dim=-1)

        loss = 0
        for l in range(sentence_length):
            loss_pos = torch.exp(similarity_function(representations[:,l,:],representations_pos[:,l,:])/self.lamb4)
            loss_neg = torch.exp(similarity_function(representations[:,l,:],representations_neg[:,l,:])/self.lamb4)
            loss += torch.mean(-torch.log(loss_pos/(loss_pos+loss_neg)))

        return loss

    def neg_log_likelihood_loss(self, gaz_list, word_inputs, biword_inputs, word_seq_lengths, layer_gaz, gaz_count,
                                gaz_chars, gaz_mask, gazchar_mask, mask, batch_label, batch_bert, bert_mask ):

        loss_bcl, loss_ccl, tags = self.Contrastive_Loss(gaz_list, word_inputs, biword_inputs, layer_gaz, gaz_count,
                                                     gaz_chars, gaz_mask,
                                                     gazchar_mask, mask, word_seq_lengths, batch_bert, bert_mask)
        ner_loss = self.crf.neg_log_likelihood_loss(tags, mask, batch_label)
        scores, tag_seq = self.crf._viterbi_decode(tags, mask)
        return ner_loss*self.lamb1 + self.lamb2 * loss_bcl + loss_ccl * self.lamb3, tag_seq

    def forward(self, gaz_list, word_inputs, biword_inputs, word_seq_lengths, layer_gaz, gaz_count, gaz_chars, gaz_mask,
                gazchar_mask, mask, batch_bert, bert_mask):

        tags, gaz_match = self.get_tags(gaz_list, word_inputs, biword_inputs, layer_gaz, gaz_count, gaz_chars, gaz_mask,
                                        gazchar_mask, mask, word_seq_lengths, batch_bert, bert_mask)

        scores, tag_seq = self.crf._viterbi_decode(tags, mask)

        return tag_seq, gaz_match