## MGCL: Multi-Granularity Contrastive Learning Framework for Chinese NER
This repository contains the demo implementation of the AAAI 2023 submitted paper "MGCL: Multi-Granularity Contrastive Learning Framework for Chinese NER".
# Source code description
# Data Preparation
Data is available at ./data folder. 
# Requirements

```bash
pip install requirements.txt
```


# How to Run

```bash
python main.py
```






## Input format:
CoNLL format, with each character and its label split by a whitespace in a line. The "BMES" tag scheme is prefered.

别 O 

错 O

过 O

邻 O

近 O

大 B-LOC

鹏 M-LOC

湾 E-LOC

的 O

湿 O

地 O

## Pretrain embedding:
The pretrained char embedding is the same with [Lattice LSTM](https://www.aclweb.org/anthology/P18-1144)
The pretrained word embedding (Tencent embedding)  is the same with [DCSAN](https://ojs.aaai.org/index.php/AAAI/article/view/17706) (Tencent AI Lab embedding corpus for Chinese words and phrases (v0.1.0 released in October 2018)
URL: https://ai.tencent.com/ailab/nlp/data/tencent-ailab-embedding-zh-d200-v0.1.0.tar.gz)
## Run the code:
1. Download the character embeddings and word embeddings and put them in the `cpt` folder.
2. Download the four datasets in `data/MSRANER`, `data/OntoNotesNER`, `data/ResumeNER` and `data/weibo`, respectively.
3. To train on the four datasets:

